import Link from 'next/link';
import { useRouter } from 'next/router';
//import useAuth from '@/hooks/useAuth';

const Navbar = ({ authToken }) => {
    const router = useRouter();
        //const { isAuthenticated } = useAuth(authToken);

    console.log("Token: " + authToken);

    const handleLogOff = async () => {
        // Call the logout API route
        await fetch('/api/logout', {
            method: 'POST',
        });

        router.push('/login'); // Redirect to the login page
    };

    if (!authToken){
        return null
    }
    

    return (
        <nav className="bg-gray-800 p-4 text-white">
            <div className="container mx-auto flex justify-between items-center">
                <div className="flex space-x-4">
                    <Link className="hover:bg-gray-700 p-2 rounded" href="/">
                        Home
                    </Link>
                    <Link className="hover:bg-gray-700 p-2 rounded" href="/users">
                        Users
                    </Link>
                    {/* Additional links can be added here */}
                </div>
                <button onClick={handleLogOff} className="bg-red-500 hover:bg-red-700 p-2 rounded">
                    LogOff
                </button>
            </div>
        </nav>
    );
};

export default Navbar;
