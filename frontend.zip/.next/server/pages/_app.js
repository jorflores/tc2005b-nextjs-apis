/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./src/pages/_app.js":
/*!***************************!*\
  !*** ./src/pages/_app.js ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ App)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/styles/globals.css */ \"./src/styles/globals.css\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _pages_components_Navbar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../pages/components/Navbar */ \"./src/pages/components/Navbar.js\");\n\n\n\nfunction App({ Component, pageProps }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_pages_components_Navbar__WEBPACK_IMPORTED_MODULE_2__[\"default\"], {\n                authToken: pageProps.authToken\n            }, void 0, false, {\n                fileName: \"D:\\\\Playground\\\\Next\\\\2024\\\\ejemplo-back-front\\\\frontEnd\\\\mynextapp\\\\src\\\\pages\\\\_app.js\",\n                lineNumber: 5,\n                columnNumber: 12\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n                ...pageProps\n            }, void 0, false, {\n                fileName: \"D:\\\\Playground\\\\Next\\\\2024\\\\ejemplo-back-front\\\\frontEnd\\\\mynextapp\\\\src\\\\pages\\\\_app.js\",\n                lineNumber: 5,\n                columnNumber: 54\n            }, this)\n        ]\n    }, void 0, true);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvcGFnZXMvX2FwcC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBQThCO0FBQ2tCO0FBRWpDLFNBQVNDLElBQUksRUFBRUMsU0FBUyxFQUFFQyxTQUFTLEVBQUU7SUFDbEQscUJBQU87OzBCQUFFLDhEQUFDSCxnRUFBTUE7Z0JBQUNJLFdBQVdELFVBQVVDLFNBQVM7Ozs7OzswQkFBSSw4REFBQ0Y7Z0JBQVcsR0FBR0MsU0FBUzs7Ozs7Ozs7QUFDN0UiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9teW5leHRhcHAvLi9zcmMvcGFnZXMvX2FwcC5qcz84ZmRhIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBcIkAvc3R5bGVzL2dsb2JhbHMuY3NzXCI7XG5pbXBvcnQgTmF2YmFyIGZyb20gJy4uL3BhZ2VzL2NvbXBvbmVudHMvTmF2YmFyJztcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQXBwKHsgQ29tcG9uZW50LCBwYWdlUHJvcHMgfSkge1xuICByZXR1cm4gPD48TmF2YmFyIGF1dGhUb2tlbj17cGFnZVByb3BzLmF1dGhUb2tlbn0gLz48Q29tcG9uZW50IHsuLi5wYWdlUHJvcHN9IC8+PC8+XG59XG4iXSwibmFtZXMiOlsiTmF2YmFyIiwiQXBwIiwiQ29tcG9uZW50IiwicGFnZVByb3BzIiwiYXV0aFRva2VuIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./src/pages/_app.js\n");

/***/ }),

/***/ "./src/pages/components/Navbar.js":
/*!****************************************!*\
  !*** ./src/pages/components/Navbar.js ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/link */ \"./node_modules/next/link.js\");\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ \"./node_modules/next/router.js\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\n//import useAuth from '@/hooks/useAuth';\nconst Navbar = ({ authToken })=>{\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();\n    //const { isAuthenticated } = useAuth(authToken);\n    console.log(\"Token: \" + authToken);\n    const handleLogOff = async ()=>{\n        // Call the logout API route\n        await fetch(\"/api/logout\", {\n            method: \"POST\"\n        });\n        router.push(\"/login\"); // Redirect to the login page\n    };\n    if (!authToken) {\n        return null;\n    }\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"nav\", {\n        className: \"bg-gray-800 p-4 text-white\",\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n            className: \"container mx-auto flex justify-between items-center\",\n            children: [\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                    className: \"flex space-x-4\",\n                    children: [\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {\n                            className: \"hover:bg-gray-700 p-2 rounded\",\n                            href: \"/\",\n                            children: \"Home\"\n                        }, void 0, false, {\n                            fileName: \"D:\\\\Playground\\\\Next\\\\2024\\\\ejemplo-back-front\\\\frontEnd\\\\mynextapp\\\\src\\\\pages\\\\components\\\\Navbar.js\",\n                            lineNumber: 29,\n                            columnNumber: 21\n                        }, undefined),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {\n                            className: \"hover:bg-gray-700 p-2 rounded\",\n                            href: \"/users\",\n                            children: \"Users\"\n                        }, void 0, false, {\n                            fileName: \"D:\\\\Playground\\\\Next\\\\2024\\\\ejemplo-back-front\\\\frontEnd\\\\mynextapp\\\\src\\\\pages\\\\components\\\\Navbar.js\",\n                            lineNumber: 32,\n                            columnNumber: 21\n                        }, undefined)\n                    ]\n                }, void 0, true, {\n                    fileName: \"D:\\\\Playground\\\\Next\\\\2024\\\\ejemplo-back-front\\\\frontEnd\\\\mynextapp\\\\src\\\\pages\\\\components\\\\Navbar.js\",\n                    lineNumber: 28,\n                    columnNumber: 17\n                }, undefined),\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                    onClick: handleLogOff,\n                    className: \"bg-red-500 hover:bg-red-700 p-2 rounded\",\n                    children: \"LogOff\"\n                }, void 0, false, {\n                    fileName: \"D:\\\\Playground\\\\Next\\\\2024\\\\ejemplo-back-front\\\\frontEnd\\\\mynextapp\\\\src\\\\pages\\\\components\\\\Navbar.js\",\n                    lineNumber: 37,\n                    columnNumber: 17\n                }, undefined)\n            ]\n        }, void 0, true, {\n            fileName: \"D:\\\\Playground\\\\Next\\\\2024\\\\ejemplo-back-front\\\\frontEnd\\\\mynextapp\\\\src\\\\pages\\\\components\\\\Navbar.js\",\n            lineNumber: 27,\n            columnNumber: 13\n        }, undefined)\n    }, void 0, false, {\n        fileName: \"D:\\\\Playground\\\\Next\\\\2024\\\\ejemplo-back-front\\\\frontEnd\\\\mynextapp\\\\src\\\\pages\\\\components\\\\Navbar.js\",\n        lineNumber: 26,\n        columnNumber: 9\n    }, undefined);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Navbar);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvcGFnZXMvY29tcG9uZW50cy9OYXZiYXIuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7QUFBNkI7QUFDVztBQUN4Qyx3Q0FBd0M7QUFFeEMsTUFBTUUsU0FBUyxDQUFDLEVBQUVDLFNBQVMsRUFBRTtJQUN6QixNQUFNQyxTQUFTSCxzREFBU0E7SUFDcEIsaURBQWlEO0lBRXJESSxRQUFRQyxHQUFHLENBQUMsWUFBWUg7SUFFeEIsTUFBTUksZUFBZTtRQUNqQiw0QkFBNEI7UUFDNUIsTUFBTUMsTUFBTSxlQUFlO1lBQ3ZCQyxRQUFRO1FBQ1o7UUFFQUwsT0FBT00sSUFBSSxDQUFDLFdBQVcsNkJBQTZCO0lBQ3hEO0lBRUEsSUFBSSxDQUFDUCxXQUFVO1FBQ1gsT0FBTztJQUNYO0lBR0EscUJBQ0ksOERBQUNRO1FBQUlDLFdBQVU7a0JBQ1gsNEVBQUNDO1lBQUlELFdBQVU7OzhCQUNYLDhEQUFDQztvQkFBSUQsV0FBVTs7c0NBQ1gsOERBQUNaLGtEQUFJQTs0QkFBQ1ksV0FBVTs0QkFBZ0NFLE1BQUs7c0NBQUk7Ozs7OztzQ0FHekQsOERBQUNkLGtEQUFJQTs0QkFBQ1ksV0FBVTs0QkFBZ0NFLE1BQUs7c0NBQVM7Ozs7Ozs7Ozs7Ozs4QkFLbEUsOERBQUNDO29CQUFPQyxTQUFTVDtvQkFBY0ssV0FBVTs4QkFBMEM7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBTW5HO0FBRUEsaUVBQWVWLE1BQU1BLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9teW5leHRhcHAvLi9zcmMvcGFnZXMvY29tcG9uZW50cy9OYXZiYXIuanM/YzYyYiJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgTGluayBmcm9tICduZXh0L2xpbmsnO1xyXG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tICduZXh0L3JvdXRlcic7XHJcbi8vaW1wb3J0IHVzZUF1dGggZnJvbSAnQC9ob29rcy91c2VBdXRoJztcclxuXHJcbmNvbnN0IE5hdmJhciA9ICh7IGF1dGhUb2tlbiB9KSA9PiB7XHJcbiAgICBjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcclxuICAgICAgICAvL2NvbnN0IHsgaXNBdXRoZW50aWNhdGVkIH0gPSB1c2VBdXRoKGF1dGhUb2tlbik7XHJcblxyXG4gICAgY29uc29sZS5sb2coXCJUb2tlbjogXCIgKyBhdXRoVG9rZW4pO1xyXG5cclxuICAgIGNvbnN0IGhhbmRsZUxvZ09mZiA9IGFzeW5jICgpID0+IHtcclxuICAgICAgICAvLyBDYWxsIHRoZSBsb2dvdXQgQVBJIHJvdXRlXHJcbiAgICAgICAgYXdhaXQgZmV0Y2goJy9hcGkvbG9nb3V0Jywge1xyXG4gICAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcm91dGVyLnB1c2goJy9sb2dpbicpOyAvLyBSZWRpcmVjdCB0byB0aGUgbG9naW4gcGFnZVxyXG4gICAgfTtcclxuXHJcbiAgICBpZiAoIWF1dGhUb2tlbil7XHJcbiAgICAgICAgcmV0dXJuIG51bGxcclxuICAgIH1cclxuICAgIFxyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPG5hdiBjbGFzc05hbWU9XCJiZy1ncmF5LTgwMCBwLTQgdGV4dC13aGl0ZVwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhaW5lciBteC1hdXRvIGZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxMaW5rIGNsYXNzTmFtZT1cImhvdmVyOmJnLWdyYXktNzAwIHAtMiByb3VuZGVkXCIgaHJlZj1cIi9cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgSG9tZVxyXG4gICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICA8TGluayBjbGFzc05hbWU9XCJob3ZlcjpiZy1ncmF5LTcwMCBwLTIgcm91bmRlZFwiIGhyZWY9XCIvdXNlcnNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgVXNlcnNcclxuICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgey8qIEFkZGl0aW9uYWwgbGlua3MgY2FuIGJlIGFkZGVkIGhlcmUgKi99XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17aGFuZGxlTG9nT2ZmfSBjbGFzc05hbWU9XCJiZy1yZWQtNTAwIGhvdmVyOmJnLXJlZC03MDAgcC0yIHJvdW5kZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICBMb2dPZmZcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L25hdj5cclxuICAgICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBOYXZiYXI7XHJcbiJdLCJuYW1lcyI6WyJMaW5rIiwidXNlUm91dGVyIiwiTmF2YmFyIiwiYXV0aFRva2VuIiwicm91dGVyIiwiY29uc29sZSIsImxvZyIsImhhbmRsZUxvZ09mZiIsImZldGNoIiwibWV0aG9kIiwicHVzaCIsIm5hdiIsImNsYXNzTmFtZSIsImRpdiIsImhyZWYiLCJidXR0b24iLCJvbkNsaWNrIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./src/pages/components/Navbar.js\n");

/***/ }),

/***/ "./src/styles/globals.css":
/*!********************************!*\
  !*** ./src/styles/globals.css ***!
  \********************************/
/***/ (() => {



/***/ }),

/***/ "next/dist/compiled/next-server/pages.runtime.dev.js":
/*!**********************************************************************!*\
  !*** external "next/dist/compiled/next-server/pages.runtime.dev.js" ***!
  \**********************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/pages.runtime.dev.js");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react-dom":
/*!****************************!*\
  !*** external "react-dom" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "react/jsx-runtime":
/*!************************************!*\
  !*** external "react/jsx-runtime" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ "fs":
/*!*********************!*\
  !*** external "fs" ***!
  \*********************/
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ "stream":
/*!*************************!*\
  !*** external "stream" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ "zlib":
/*!***********************!*\
  !*** external "zlib" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/@swc"], () => (__webpack_exec__("./src/pages/_app.js")));
module.exports = __webpack_exports__;

})();