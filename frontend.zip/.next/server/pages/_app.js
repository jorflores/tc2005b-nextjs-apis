/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./src/hooks/useAuth.js":
/*!******************************!*\
  !*** ./src/hooks/useAuth.js ***!
  \******************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/router */ \"./node_modules/next/router.js\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! axios */ \"axios\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_2__]);\naxios__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\nconst useAuth = ()=>{\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();\n    const [isAuthenticated, setIsAuthenticated] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);\n    const [isLoading, setIsLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);\n    const [role, setRole] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(\"\");\n    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)((authRequired)=>{\n        const validateToken = async ()=>{\n            const token = localStorage.getItem(\"token\");\n            if (!token) {\n                setIsAuthenticated(false);\n                setIsLoading(false);\n                if (authRequired) {\n                    router.push(\"/login\");\n                }\n                return;\n            }\n            try {\n                const response = await axios__WEBPACK_IMPORTED_MODULE_2__[\"default\"].post(\"/api/validate-token\", {}, {\n                    headers: {\n                        \"Authorization\": `Bearer ${token}`\n                    }\n                });\n                if (response.status === 200 && response.data.isValid) {\n                    console.log(response.data);\n                    setIsAuthenticated(true);\n                    setRole(response.data.userRole);\n                } else {\n                    throw new Error(\"Token validation failed\");\n                }\n            } catch (error) {\n                console.error(\"Error validating token:\", error);\n                localStorage.removeItem(\"token\");\n                router.push(\"/login\");\n            }\n            setIsLoading(false);\n        };\n        validateToken();\n    }, [\n        router\n    ]);\n    return {\n        isLoading,\n        isAuthenticated,\n        role\n    };\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useAuth);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvaG9va3MvdXNlQXV0aC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7QUFBNEM7QUFDSjtBQUNaO0FBRTVCLE1BQU1JLFVBQVU7SUFDWixNQUFNQyxTQUFTSCxzREFBU0E7SUFDeEIsTUFBTSxDQUFDSSxpQkFBaUJDLG1CQUFtQixHQUFHTiwrQ0FBUUEsQ0FBQztJQUN2RCxNQUFNLENBQUNPLFdBQVdDLGFBQWEsR0FBR1IsK0NBQVFBLENBQUM7SUFDM0MsTUFBTSxDQUFDUyxNQUFNQyxRQUFRLEdBQUdWLCtDQUFRQSxDQUFDO0lBRWpDRCxnREFBU0EsQ0FBQyxDQUFDWTtRQUNQLE1BQU1DLGdCQUFnQjtZQUNsQixNQUFNQyxRQUFRQyxhQUFhQyxPQUFPLENBQUM7WUFDbkMsSUFBSSxDQUFDRixPQUFPO2dCQUNSUCxtQkFBbUI7Z0JBQ25CRSxhQUFhO2dCQUNiLElBQUdHLGNBQWE7b0JBQ2hCUCxPQUFPWSxJQUFJLENBQUM7Z0JBQ1o7Z0JBQ0E7WUFDSjtZQUVBLElBQUk7Z0JBQ0EsTUFBTUMsV0FBVyxNQUFNZixrREFBVSxDQUFDLHVCQUF1QixDQUFDLEdBQUc7b0JBQ3pEaUIsU0FBUzt3QkFDTCxpQkFBaUIsQ0FBQyxPQUFPLEVBQUVOLE1BQU0sQ0FBQztvQkFDdEM7Z0JBQ0o7Z0JBRUEsSUFBSUksU0FBU0csTUFBTSxLQUFLLE9BQU9ILFNBQVNJLElBQUksQ0FBQ0MsT0FBTyxFQUFFO29CQUNsREMsUUFBUUMsR0FBRyxDQUFDUCxTQUFTSSxJQUFJO29CQUN6QmYsbUJBQW1CO29CQUNuQkksUUFBUU8sU0FBU0ksSUFBSSxDQUFDSSxRQUFRO2dCQUNsQyxPQUFPO29CQUNILE1BQU0sSUFBSUMsTUFBTTtnQkFDcEI7WUFDSixFQUFFLE9BQU9DLE9BQU87Z0JBQ1pKLFFBQVFJLEtBQUssQ0FBQywyQkFBMkJBO2dCQUN6Q2IsYUFBYWMsVUFBVSxDQUFDO2dCQUN4QnhCLE9BQU9ZLElBQUksQ0FBQztZQUNoQjtZQUNBUixhQUFhO1FBQ2pCO1FBRUFJO0lBQ0osR0FBRztRQUFDUjtLQUFPO0lBRVgsT0FBTztRQUFFRztRQUFXRjtRQUFnQkk7SUFBSztBQUM3QztBQUVBLGlFQUFlTixPQUFPQSxFQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vbXluZXh0YXBwLy4vc3JjL2hvb2tzL3VzZUF1dGguanM/YTRmMSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tICduZXh0L3JvdXRlcic7XHJcbmltcG9ydCAgYXhpb3MgIGZyb20gJ2F4aW9zJztcclxuXHJcbmNvbnN0IHVzZUF1dGggPSAoKSA9PiB7XHJcbiAgICBjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcclxuICAgIGNvbnN0IFtpc0F1dGhlbnRpY2F0ZWQsIHNldElzQXV0aGVudGljYXRlZF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSk7XHJcbiAgICBjb25zdCBbcm9sZSwgc2V0Um9sZV0gPSB1c2VTdGF0ZShcIlwiKVxyXG5cclxuICAgIHVzZUVmZmVjdCgoYXV0aFJlcXVpcmVkKSA9PiB7XHJcbiAgICAgICAgY29uc3QgdmFsaWRhdGVUb2tlbiA9IGFzeW5jICgpID0+IHtcclxuICAgICAgICAgICAgY29uc3QgdG9rZW4gPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgndG9rZW4nKTtcclxuICAgICAgICAgICAgaWYgKCF0b2tlbikge1xyXG4gICAgICAgICAgICAgICAgc2V0SXNBdXRoZW50aWNhdGVkKGZhbHNlKTtcclxuICAgICAgICAgICAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICBpZihhdXRoUmVxdWlyZWQpe1xyXG4gICAgICAgICAgICAgICAgcm91dGVyLnB1c2goJy9sb2dpbicpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBheGlvcy5wb3N0KCcvYXBpL3ZhbGlkYXRlLXRva2VuJywge30sIHtcclxuICAgICAgICAgICAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdBdXRob3JpemF0aW9uJzogYEJlYXJlciAke3Rva2VufWBcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzID09PSAyMDAgJiYgcmVzcG9uc2UuZGF0YS5pc1ZhbGlkKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2cocmVzcG9uc2UuZGF0YSlcclxuICAgICAgICAgICAgICAgICAgICBzZXRJc0F1dGhlbnRpY2F0ZWQodHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0Um9sZShyZXNwb25zZS5kYXRhLnVzZXJSb2xlKVxyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1Rva2VuIHZhbGlkYXRpb24gZmFpbGVkJyk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKCdFcnJvciB2YWxpZGF0aW5nIHRva2VuOicsIGVycm9yKTtcclxuICAgICAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKCd0b2tlbicpO1xyXG4gICAgICAgICAgICAgICAgcm91dGVyLnB1c2goJy9sb2dpbicpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgdmFsaWRhdGVUb2tlbigpO1xyXG4gICAgfSwgW3JvdXRlcl0pO1xyXG5cclxuICAgIHJldHVybiB7IGlzTG9hZGluZywgaXNBdXRoZW50aWNhdGVkLHJvbGUgfTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IHVzZUF1dGg7XHJcbiJdLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsInVzZVJvdXRlciIsImF4aW9zIiwidXNlQXV0aCIsInJvdXRlciIsImlzQXV0aGVudGljYXRlZCIsInNldElzQXV0aGVudGljYXRlZCIsImlzTG9hZGluZyIsInNldElzTG9hZGluZyIsInJvbGUiLCJzZXRSb2xlIiwiYXV0aFJlcXVpcmVkIiwidmFsaWRhdGVUb2tlbiIsInRva2VuIiwibG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSIsInB1c2giLCJyZXNwb25zZSIsInBvc3QiLCJoZWFkZXJzIiwic3RhdHVzIiwiZGF0YSIsImlzVmFsaWQiLCJjb25zb2xlIiwibG9nIiwidXNlclJvbGUiLCJFcnJvciIsImVycm9yIiwicmVtb3ZlSXRlbSJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/hooks/useAuth.js\n");

/***/ }),

/***/ "./src/pages/_app.js":
/*!***************************!*\
  !*** ./src/pages/_app.js ***!
  \***************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ App)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/styles/globals.css */ \"./src/styles/globals.css\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _pages_components_Navbar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../pages/components/Navbar */ \"./src/pages/components/Navbar.js\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_pages_components_Navbar__WEBPACK_IMPORTED_MODULE_2__]);\n_pages_components_Navbar__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\nfunction App({ Component, pageProps }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_pages_components_Navbar__WEBPACK_IMPORTED_MODULE_2__[\"default\"], {}, void 0, false, {\n                fileName: \"D:\\\\Playground\\\\Next\\\\2024\\\\ejemplo-back-front\\\\frontEnd\\\\mynextapp\\\\src\\\\pages\\\\_app.js\",\n                lineNumber: 5,\n                columnNumber: 12\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n                ...pageProps\n            }, void 0, false, {\n                fileName: \"D:\\\\Playground\\\\Next\\\\2024\\\\ejemplo-back-front\\\\frontEnd\\\\mynextapp\\\\src\\\\pages\\\\_app.js\",\n                lineNumber: 5,\n                columnNumber: 22\n            }, this)\n        ]\n    }, void 0, true);\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvcGFnZXMvX2FwcC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7O0FBQThCO0FBQ2tCO0FBRWpDLFNBQVNDLElBQUksRUFBRUMsU0FBUyxFQUFFQyxTQUFTLEVBQUU7SUFDbEQscUJBQU87OzBCQUFFLDhEQUFDSCxnRUFBTUE7Ozs7OzBCQUFHLDhEQUFDRTtnQkFBVyxHQUFHQyxTQUFTOzs7Ozs7OztBQUM3QyIsInNvdXJjZXMiOlsid2VicGFjazovL215bmV4dGFwcC8uL3NyYy9wYWdlcy9fYXBwLmpzPzhmZGEiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFwiQC9zdHlsZXMvZ2xvYmFscy5jc3NcIjtcbmltcG9ydCBOYXZiYXIgZnJvbSAnLi4vcGFnZXMvY29tcG9uZW50cy9OYXZiYXInO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBBcHAoeyBDb21wb25lbnQsIHBhZ2VQcm9wcyB9KSB7XG4gIHJldHVybiA8PjxOYXZiYXIgLz48Q29tcG9uZW50IHsuLi5wYWdlUHJvcHN9IC8+PC8+XG59XG4iXSwibmFtZXMiOlsiTmF2YmFyIiwiQXBwIiwiQ29tcG9uZW50IiwicGFnZVByb3BzIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./src/pages/_app.js\n");

/***/ }),

/***/ "./src/pages/components/Navbar.js":
/*!****************************************!*\
  !*** ./src/pages/components/Navbar.js ***!
  \****************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/link */ \"./node_modules/next/link.js\");\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ \"./node_modules/next/router.js\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _hooks_useAuth__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/hooks/useAuth */ \"./src/hooks/useAuth.js\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_useAuth__WEBPACK_IMPORTED_MODULE_3__]);\n_hooks_useAuth__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\n\nconst Navbar = ()=>{\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();\n    const { isLoading, isAuthenticated, role } = (0,_hooks_useAuth__WEBPACK_IMPORTED_MODULE_3__[\"default\"])(false);\n    const handleLogOff = ()=>{\n        localStorage.removeItem(\"token\"); // Elimina el token de localStorage\n        router.push(\"/login\"); // Redirige al usuario a la página de login\n    };\n    /*\r\n    if (isLoading) {\r\n        return <div>Loading...</div>;\r\n    }\r\n    \r\n\r\n\r\n    if (!isAuthenticated) {\r\n        return null;  // or a minimal layout that doesn't show protected content\r\n    }*/ return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"nav\", {\n        className: \"bg-gray-800 p-4 text-white\",\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n            className: \"container mx-auto flex justify-between items-center\",\n            children: [\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                    className: \"flex space-x-4\",\n                    children: [\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {\n                            className: \"hover:bg-gray-700 p-2 rounded\",\n                            href: \"/\",\n                            children: \"Home\"\n                        }, void 0, false, {\n                            fileName: \"D:\\\\Playground\\\\Next\\\\2024\\\\ejemplo-back-front\\\\frontEnd\\\\mynextapp\\\\src\\\\pages\\\\components\\\\Navbar.js\",\n                            lineNumber: 28,\n                            columnNumber: 21\n                        }, undefined),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {\n                            className: \"hover:bg-gray-700 p-2 rounded\",\n                            href: \"/users\",\n                            children: \"Users\"\n                        }, void 0, false, {\n                            fileName: \"D:\\\\Playground\\\\Next\\\\2024\\\\ejemplo-back-front\\\\frontEnd\\\\mynextapp\\\\src\\\\pages\\\\components\\\\Navbar.js\",\n                            lineNumber: 32,\n                            columnNumber: 21\n                        }, undefined)\n                    ]\n                }, void 0, true, {\n                    fileName: \"D:\\\\Playground\\\\Next\\\\2024\\\\ejemplo-back-front\\\\frontEnd\\\\mynextapp\\\\src\\\\pages\\\\components\\\\Navbar.js\",\n                    lineNumber: 27,\n                    columnNumber: 17\n                }, undefined),\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                    onClick: handleLogOff,\n                    className: \"bg-red-500 hover:bg-red-700 p-2 rounded\",\n                    children: \"LogOff\"\n                }, void 0, false, {\n                    fileName: \"D:\\\\Playground\\\\Next\\\\2024\\\\ejemplo-back-front\\\\frontEnd\\\\mynextapp\\\\src\\\\pages\\\\components\\\\Navbar.js\",\n                    lineNumber: 38,\n                    columnNumber: 17\n                }, undefined)\n            ]\n        }, void 0, true, {\n            fileName: \"D:\\\\Playground\\\\Next\\\\2024\\\\ejemplo-back-front\\\\frontEnd\\\\mynextapp\\\\src\\\\pages\\\\components\\\\Navbar.js\",\n            lineNumber: 26,\n            columnNumber: 13\n        }, undefined)\n    }, void 0, false, {\n        fileName: \"D:\\\\Playground\\\\Next\\\\2024\\\\ejemplo-back-front\\\\frontEnd\\\\mynextapp\\\\src\\\\pages\\\\components\\\\Navbar.js\",\n        lineNumber: 25,\n        columnNumber: 9\n    }, undefined);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Navbar);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvcGFnZXMvY29tcG9uZW50cy9OYXZiYXIuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7O0FBQTZCO0FBQ1c7QUFDRjtBQUV0QyxNQUFNRyxTQUFTO0lBQ1gsTUFBTUMsU0FBU0gsc0RBQVNBO0lBQ3hCLE1BQU0sRUFBRUksU0FBUyxFQUFFQyxlQUFlLEVBQUVDLElBQUksRUFBRSxHQUFHTCwwREFBT0EsQ0FBQztJQUNyRCxNQUFNTSxlQUFlO1FBQ2pCQyxhQUFhQyxVQUFVLENBQUMsVUFBVSxtQ0FBbUM7UUFDckVOLE9BQU9PLElBQUksQ0FBQyxXQUFXLDJDQUEyQztJQUN0RTtJQUVBOzs7Ozs7Ozs7S0FTQyxHQUVELHFCQUNJLDhEQUFDQztRQUFJQyxXQUFVO2tCQUNYLDRFQUFDQztZQUFJRCxXQUFVOzs4QkFDWCw4REFBQ0M7b0JBQUlELFdBQVU7O3NDQUNYLDhEQUFDYixrREFBSUE7NEJBQUNhLFdBQVU7NEJBQWdDRSxNQUFLO3NDQUFJOzs7Ozs7c0NBSXpELDhEQUFDZixrREFBSUE7NEJBQUNhLFdBQVU7NEJBQWdDRSxNQUFLO3NDQUFTOzs7Ozs7Ozs7Ozs7OEJBTWxFLDhEQUFDQztvQkFBT0MsU0FBU1Q7b0JBQWNLLFdBQVU7OEJBQTBDOzs7Ozs7Ozs7Ozs7Ozs7OztBQU1uRztBQUVBLGlFQUFlVixNQUFNQSxFQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vbXluZXh0YXBwLy4vc3JjL3BhZ2VzL2NvbXBvbmVudHMvTmF2YmFyLmpzP2M2MmIiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IExpbmsgZnJvbSAnbmV4dC9saW5rJztcclxuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSAnbmV4dC9yb3V0ZXInO1xyXG5pbXBvcnQgdXNlQXV0aCBmcm9tIFwiQC9ob29rcy91c2VBdXRoXCI7XHJcblxyXG5jb25zdCBOYXZiYXIgPSAoKSA9PiB7XHJcbiAgICBjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcclxuICAgIGNvbnN0IHsgaXNMb2FkaW5nLCBpc0F1dGhlbnRpY2F0ZWQsIHJvbGUgfSA9IHVzZUF1dGgoZmFsc2UpO1xyXG4gICAgY29uc3QgaGFuZGxlTG9nT2ZmID0gKCkgPT4ge1xyXG4gICAgICAgIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKCd0b2tlbicpOyAvLyBFbGltaW5hIGVsIHRva2VuIGRlIGxvY2FsU3RvcmFnZVxyXG4gICAgICAgIHJvdXRlci5wdXNoKCcvbG9naW4nKTsgLy8gUmVkaXJpZ2UgYWwgdXN1YXJpbyBhIGxhIHDDoWdpbmEgZGUgbG9naW5cclxuICAgIH07XHJcblxyXG4gICAgLypcclxuICAgIGlmIChpc0xvYWRpbmcpIHtcclxuICAgICAgICByZXR1cm4gPGRpdj5Mb2FkaW5nLi4uPC9kaXY+O1xyXG4gICAgfVxyXG4gICAgXHJcblxyXG5cclxuICAgIGlmICghaXNBdXRoZW50aWNhdGVkKSB7XHJcbiAgICAgICAgcmV0dXJuIG51bGw7ICAvLyBvciBhIG1pbmltYWwgbGF5b3V0IHRoYXQgZG9lc24ndCBzaG93IHByb3RlY3RlZCBjb250ZW50XHJcbiAgICB9Ki9cclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxuYXYgY2xhc3NOYW1lPVwiYmctZ3JheS04MDAgcC00IHRleHQtd2hpdGVcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWluZXIgbXgtYXV0byBmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8TGluayBjbGFzc05hbWU9XCJob3ZlcjpiZy1ncmF5LTcwMCBwLTIgcm91bmRlZFwiIGhyZWY9XCIvXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEhvbWVcclxuICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxMaW5rIGNsYXNzTmFtZT1cImhvdmVyOmJnLWdyYXktNzAwIHAtMiByb3VuZGVkXCIgaHJlZj1cIi91c2Vyc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIFVzZXJzXHJcbiAgICAgICAgICAgICAgICA8L0xpbms+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBQdWVkZXMgYWdyZWdhciBtw6FzIGVubGFjZXMgYXF1w60gc2kgbmVjZXNpdGFzICovfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e2hhbmRsZUxvZ09mZn0gY2xhc3NOYW1lPVwiYmctcmVkLTUwMCBob3ZlcjpiZy1yZWQtNzAwIHAtMiByb3VuZGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgTG9nT2ZmXHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9uYXY+XHJcbiAgICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgTmF2YmFyO1xyXG4iXSwibmFtZXMiOlsiTGluayIsInVzZVJvdXRlciIsInVzZUF1dGgiLCJOYXZiYXIiLCJyb3V0ZXIiLCJpc0xvYWRpbmciLCJpc0F1dGhlbnRpY2F0ZWQiLCJyb2xlIiwiaGFuZGxlTG9nT2ZmIiwibG9jYWxTdG9yYWdlIiwicmVtb3ZlSXRlbSIsInB1c2giLCJuYXYiLCJjbGFzc05hbWUiLCJkaXYiLCJocmVmIiwiYnV0dG9uIiwib25DbGljayJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/pages/components/Navbar.js\n");

/***/ }),

/***/ "./src/styles/globals.css":
/*!********************************!*\
  !*** ./src/styles/globals.css ***!
  \********************************/
/***/ (() => {



/***/ }),

/***/ "next/dist/compiled/next-server/pages.runtime.dev.js":
/*!**********************************************************************!*\
  !*** external "next/dist/compiled/next-server/pages.runtime.dev.js" ***!
  \**********************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/pages.runtime.dev.js");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react-dom":
/*!****************************!*\
  !*** external "react-dom" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "react/jsx-runtime":
/*!************************************!*\
  !*** external "react/jsx-runtime" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ "axios":
/*!************************!*\
  !*** external "axios" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ }),

/***/ "fs":
/*!*********************!*\
  !*** external "fs" ***!
  \*********************/
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ "stream":
/*!*************************!*\
  !*** external "stream" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ "zlib":
/*!***********************!*\
  !*** external "zlib" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/@swc"], () => (__webpack_exec__("./src/pages/_app.js")));
module.exports = __webpack_exports__;

})();